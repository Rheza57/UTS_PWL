
    <h1>Hello, <?= $this->session->userdata('level'); ?>!</h1>

    