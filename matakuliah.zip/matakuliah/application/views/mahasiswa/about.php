<h3 style="margin-top: 60px">
    <center>
        Welcome <?= $this->session->userdata('level') ?><br>
        <img src="<?php echo base_url(); ?>assets/image/polinema.jpg"width="300px">
        <br>Daftar Matakuliah Mahasiswa 
    </center>
</h3>
<h6 style="margin-top: 100px;text-align: center">
    Copyright <?= date("Y") ?>. Created By 
</h6>
<h6 style="margin-top: 50px;text-align: center">
        Rahmad Alfian Maskuri (1841720048/TI 2A)
</h6>
<h6 style="margin-top: 10px;text-align: center">
        Achmad Rheza (1841720113/TI 2A)
</h6>
